codigo = 105
salario = 1650.00
nome = "José Santana"
ativo= True

print("Código: %d "% codigo)
print("Nome: %s "% nome)
print("Sálario: %.2f " % salario)
print("Ativo: %r " % ativo)
